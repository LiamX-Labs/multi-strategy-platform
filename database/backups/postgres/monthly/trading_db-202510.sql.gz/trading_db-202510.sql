--
-- PostgreSQL database dump
--

\restrict vR3hVGwVM2xe9dZOiRd2pzhdvCKddNhZWsvSArJINBXBfWQbs0fFgoaiG5sUFB1

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: trading; Type: SCHEMA; Schema: -; Owner: trading_user
--

CREATE SCHEMA trading;


ALTER SCHEMA trading OWNER TO trading_user;

--
-- Name: SCHEMA trading; Type: COMMENT; Schema: -; Owner: trading_user
--

COMMENT ON SCHEMA trading IS 'Core trading operations schema';


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bots; Type: TABLE; Schema: trading; Owner: trading_user
--

CREATE TABLE trading.bots (
    bot_id character varying(50) NOT NULL,
    bot_name character varying(100) NOT NULL,
    bot_type character varying(50) NOT NULL,
    strategy_name character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    deployment_mode character varying(20) NOT NULL,
    initial_capital numeric(20,8) NOT NULL,
    current_equity numeric(20,8),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_heartbeat timestamp with time zone,
    CONSTRAINT valid_mode CHECK (((deployment_mode)::text = ANY ((ARRAY['live'::character varying, 'demo'::character varying])::text[]))),
    CONSTRAINT valid_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'paused'::character varying, 'stopped'::character varying])::text[])))
);


ALTER TABLE trading.bots OWNER TO trading_user;

--
-- Name: TABLE bots; Type: COMMENT; Schema: trading; Owner: trading_user
--

COMMENT ON TABLE trading.bots IS 'Registry of all trading bots';


--
-- Name: fills; Type: TABLE; Schema: trading; Owner: trading_user
--

CREATE TABLE trading.fills (
    id bigint NOT NULL,
    bot_id character varying(50) NOT NULL,
    symbol character varying(20) NOT NULL,
    order_id character varying(100) NOT NULL,
    client_order_id character varying(100) NOT NULL,
    side character varying(10) NOT NULL,
    exec_price numeric(20,8) NOT NULL,
    exec_qty numeric(20,8) NOT NULL,
    exec_time timestamp with time zone NOT NULL,
    close_reason character varying(50),
    commission numeric(20,8) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT positive_price CHECK ((exec_price > (0)::numeric)),
    CONSTRAINT positive_qty CHECK ((exec_qty > (0)::numeric)),
    CONSTRAINT valid_side CHECK (((side)::text = ANY ((ARRAY['Buy'::character varying, 'Sell'::character varying])::text[])))
);


ALTER TABLE trading.fills OWNER TO trading_user;

--
-- Name: daily_performance; Type: VIEW; Schema: trading; Owner: trading_user
--

CREATE VIEW trading.daily_performance AS
 SELECT date(fills.exec_time) AS trade_date,
    fills.bot_id,
    count(*) AS total_fills,
    sum(
        CASE
            WHEN ((fills.side)::text = 'Buy'::text) THEN 1
            ELSE 0
        END) AS buy_fills,
    sum(
        CASE
            WHEN ((fills.side)::text = 'Sell'::text) THEN 1
            ELSE 0
        END) AS sell_fills,
    sum(fills.commission) AS total_fees,
    count(DISTINCT fills.symbol) AS symbols_traded
   FROM trading.fills
  GROUP BY (date(fills.exec_time)), fills.bot_id
  ORDER BY (date(fills.exec_time)) DESC;


ALTER TABLE trading.daily_performance OWNER TO trading_user;

--
-- Name: fills_id_seq; Type: SEQUENCE; Schema: trading; Owner: trading_user
--

CREATE SEQUENCE trading.fills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE trading.fills_id_seq OWNER TO trading_user;

--
-- Name: fills_id_seq; Type: SEQUENCE OWNED BY; Schema: trading; Owner: trading_user
--

ALTER SEQUENCE trading.fills_id_seq OWNED BY trading.fills.id;


--
-- Name: orders; Type: TABLE; Schema: trading; Owner: trading_user
--

CREATE TABLE trading.orders (
    id bigint NOT NULL,
    bot_id character varying(50) NOT NULL,
    symbol character varying(20) NOT NULL,
    order_id character varying(100) NOT NULL,
    client_order_id character varying(100) NOT NULL,
    order_type character varying(20) NOT NULL,
    side character varying(10) NOT NULL,
    quantity numeric(20,8) NOT NULL,
    price numeric(20,8),
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT positive_qty CHECK ((quantity > (0)::numeric)),
    CONSTRAINT valid_order_side CHECK (((side)::text = ANY ((ARRAY['Buy'::character varying, 'Sell'::character varying])::text[])))
);


ALTER TABLE trading.orders OWNER TO trading_user;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: trading; Owner: trading_user
--

CREATE SEQUENCE trading.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE trading.orders_id_seq OWNER TO trading_user;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: trading; Owner: trading_user
--

ALTER SEQUENCE trading.orders_id_seq OWNED BY trading.orders.id;


--
-- Name: positions; Type: TABLE; Schema: trading; Owner: trading_user
--

CREATE TABLE trading.positions (
    id integer NOT NULL,
    bot_id character varying(50) NOT NULL,
    symbol character varying(20) NOT NULL,
    size numeric(20,8) NOT NULL,
    side character varying(10),
    avg_entry_price numeric(20,8),
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE trading.positions OWNER TO trading_user;

--
-- Name: positions_id_seq; Type: SEQUENCE; Schema: trading; Owner: trading_user
--

CREATE SEQUENCE trading.positions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE trading.positions_id_seq OWNER TO trading_user;

--
-- Name: positions_id_seq; Type: SEQUENCE OWNED BY; Schema: trading; Owner: trading_user
--

ALTER SEQUENCE trading.positions_id_seq OWNED BY trading.positions.id;


--
-- Name: trades_pnl; Type: VIEW; Schema: trading; Owner: trading_user
--

CREATE VIEW trading.trades_pnl AS
 WITH fills_numbered AS (
         SELECT fills.id,
            fills.bot_id,
            fills.symbol,
            fills.order_id,
            fills.client_order_id,
            fills.side,
            fills.exec_price,
            fills.exec_qty,
            fills.exec_time,
            fills.close_reason,
            fills.commission,
            fills.created_at,
            row_number() OVER (PARTITION BY fills.bot_id, fills.symbol ORDER BY fills.exec_time) AS fill_num
           FROM trading.fills
        ), buy_fills AS (
         SELECT fills_numbered.id,
            fills_numbered.bot_id,
            fills_numbered.symbol,
            fills_numbered.order_id,
            fills_numbered.client_order_id,
            fills_numbered.side,
            fills_numbered.exec_price,
            fills_numbered.exec_qty,
            fills_numbered.exec_time,
            fills_numbered.close_reason,
            fills_numbered.commission,
            fills_numbered.created_at,
            fills_numbered.fill_num
           FROM fills_numbered
          WHERE ((fills_numbered.side)::text = 'Buy'::text)
        ), sell_fills AS (
         SELECT fills_numbered.id,
            fills_numbered.bot_id,
            fills_numbered.symbol,
            fills_numbered.order_id,
            fills_numbered.client_order_id,
            fills_numbered.side,
            fills_numbered.exec_price,
            fills_numbered.exec_qty,
            fills_numbered.exec_time,
            fills_numbered.close_reason,
            fills_numbered.commission,
            fills_numbered.created_at,
            fills_numbered.fill_num
           FROM fills_numbered
          WHERE ((fills_numbered.side)::text = 'Sell'::text)
        )
 SELECT b.bot_id,
    b.symbol,
    b.exec_time AS entry_time,
    s.exec_time AS exit_time,
    b.exec_price AS entry_price,
    s.exec_price AS exit_price,
    b.exec_qty AS quantity,
    ((s.exec_price - b.exec_price) * b.exec_qty) AS gross_pnl,
    (b.commission + s.commission) AS total_fees,
    (((s.exec_price - b.exec_price) * b.exec_qty) - (b.commission + s.commission)) AS net_pnl,
    s.close_reason,
    EXTRACT(epoch FROM (s.exec_time - b.exec_time)) AS holding_seconds
   FROM (buy_fills b
     JOIN sell_fills s ON ((((b.bot_id)::text = (s.bot_id)::text) AND ((b.symbol)::text = (s.symbol)::text) AND (s.fill_num = (b.fill_num + 1)))));


ALTER TABLE trading.trades_pnl OWNER TO trading_user;

--
-- Name: fills id; Type: DEFAULT; Schema: trading; Owner: trading_user
--

ALTER TABLE ONLY trading.fills ALTER COLUMN id SET DEFAULT nextval('trading.fills_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: trading; Owner: trading_user
--

ALTER TABLE ONLY trading.orders ALTER COLUMN id SET DEFAULT nextval('trading.orders_id_seq'::regclass);


--
-- Name: positions id; Type: DEFAULT; Schema: trading; Owner: trading_user
--

ALTER TABLE ONLY trading.positions ALTER COLUMN id SET DEFAULT nextval('trading.positions_id_seq'::regclass);


--
-- Data for Name: bots; Type: TABLE DATA; Schema: trading; Owner: trading_user
--

COPY trading.bots (bot_id, bot_name, bot_type, strategy_name, status, deployment_mode, initial_capital, current_equity, created_at, updated_at, last_heartbeat) FROM stdin;
shortseller_001	Multi-Asset EMA Crossover Bot	shortseller	EMA 240/600 Crossover	active	demo	10000.00000000	10000.00000000	2025-10-24 03:21:18.104366+00	2025-10-24 03:21:18.104366+00	\N
lxalgo_001	LX Technical Analysis Bot	lxalgo	LX Multi-Indicator Strategy	active	demo	10000.00000000	10000.00000000	2025-10-24 03:21:18.104366+00	2025-10-24 03:21:18.104366+00	\N
momentum_001	Volatility Breakout Momentum Bot	momentum	4H Volatility Breakout	active	demo	10000.00000000	10000.00000000	2025-10-24 03:21:18.104366+00	2025-10-24 03:21:18.104366+00	\N
\.


--
-- Data for Name: fills; Type: TABLE DATA; Schema: trading; Owner: trading_user
--

COPY trading.fills (id, bot_id, symbol, order_id, client_order_id, side, exec_price, exec_qty, exec_time, close_reason, commission, created_at) FROM stdin;
1	shortseller_001	BTCUSDT	e5a3cafa-8f44-4b42-857a-1308609fa485	shortseller_001:phase3_test:1761282946819	Sell	111110.90000000	0.00100000	2025-10-24 05:15:47.599+00	phase3_test	0.00000000	2025-10-24 05:15:47.78177+00
2	shortseller_001	BTCUSDT	8e1ccad6-4502-49c4-938b-06bc2dd828e8	shortseller_001:phase3_test:1761283037712	Sell	111107.50000000	0.00100000	2025-10-24 05:17:18.084+00	phase3_test	0.00000000	2025-10-24 05:17:18.193829+00
3	shortseller_001	BTCUSDT	7a3b5f9a-ac33-453b-968f-353013edecb8	shortseller_001:entry:1761283206549	Buy	111088.00000000	0.00200000	2025-10-24 05:20:07.327+00	entry	0.00000000	2025-10-24 05:20:07.436718+00
4	shortseller_001	BTCUSDT	5110444b-d72b-496a-a49c-cecc9e364fc9	shortseller_001:phase3_test:1761283232355	Sell	111005.60000000	0.00100000	2025-10-24 05:20:33.133+00	phase3_test	0.00000000	2025-10-24 05:20:33.276712+00
5	shortseller_001	BTCUSDT	29699880-a2e8-4e4f-9f55-4e6e7ebcfb2c	shortseller_001:phase3_test:1761283351221	Sell	110894.90000000	0.00100000	2025-10-24 05:22:31.998+00	phase3_test	0.00000000	2025-10-24 05:22:32.107546+00
6	unknown	BTCUSDT	cc1f84a5-b9fb-404b-9048-7d7c918a64ee		Buy	111018.70000000	0.00200000	2025-10-24 05:25:08.119+00		0.00000000	2025-10-24 05:25:08.227808+00
7	shortseller_001	BTCUSDT	86fd4fd1-7af0-487f-8a6a-abaf2fb3d671	shortseller_001:phase3_test:1761283583696	Sell	111022.80000000	0.00100000	2025-10-24 05:26:23.97+00	phase3_test	0.00000000	2025-10-24 05:26:24.079617+00
8	unknown	BTCUSDT	3fa47291-b8dd-4d58-a79b-102648c59b93		Buy	111011.60000000	0.00100000	2025-10-24 05:27:03.056+00		0.00000000	2025-10-24 05:27:03.237337+00
9	shortseller_001	BTCUSDT	15a5d347-99b4-4026-a492-af15030bd033	shortseller_001:phase3_test:1761285450084	Sell	111209.40000000	0.00100000	2025-10-24 05:57:30.343+00	phase3_test	0.00000000	2025-10-24 05:57:30.505769+00
10	unknown	BTCUSDT	1fd632ad-f42b-43a8-971d-74656f34e51b		Buy	111211.50000000	0.00100000	2025-10-24 05:59:51.221+00		0.00000000	2025-10-24 05:59:51.343482+00
11	shortseller_001	BTCUSDT	c4bb874f-1e76-41fd-8ea2-bbd3688e3784	shortseller_001:all_bots_test:1761337222890	Sell	110700.00000000	0.00100000	2025-10-24 20:20:23.225+00	all_bots_test	0.00000000	2025-10-24 20:20:23.325572+00
12	lxalgo_001	SPKUSDT	5fbb8242-8539-423f-87fe-35182f26e18c	lxalgo_001:entry:1761337801402	Buy	0.04294000	4650.00000000	2025-10-24 20:30:01.929+00	entry	0.00000000	2025-10-24 20:30:02.022526+00
13	shortseller_001	BTCUSDT	a9444782-d480-41cc-9fae-1e64b6959263	shortseller_001:all_bots_test:1761337870189	Sell	110637.10000000	0.00100000	2025-10-24 20:31:10.488+00	all_bots_test	0.00000000	2025-10-24 20:31:10.580666+00
14	lxalgo_001	CLANKERUSDT	1971d984-81c9-46e0-bcd7-b637db4ef3d5	lxalgo_001:entry:1761338104012	Buy	67.66000000	2.92000000	2025-10-24 20:35:04.844+00	entry	0.00000000	2025-10-24 20:35:05.106778+00
15	shortseller_001	BTCUSDT	0758b8e0-daa3-4712-8912-5d83ad8a18e8	shortseller_001:all_bots_test:1761338193283	Sell	110700.00000000	0.00100000	2025-10-24 20:36:33.632+00	all_bots_test	0.00000000	2025-10-24 20:36:33.668892+00
16	shortseller_001	BTCUSDT	7121f560-c8a4-477b-84e6-5156e3c1975d	shortseller_001:all_bots_test:1761338358429	Sell	110617.20000000	0.00100000	2025-10-24 20:39:18.817+00	all_bots_test	0.00000000	2025-10-24 20:39:18.820501+00
17	lxalgo_001	SPKUSDT	a4e16f4a-b982-4d93-8c85-676c428138d7	lxalgo_001:entry:1761338402174	Buy	0.04539000	4390.00000000	2025-10-24 20:40:03.291+00	entry	0.00000000	2025-10-24 20:40:03.28925+00
18	lxalgo_001	EVAAUSDT	45c3b9c9-192a-4e6a-99ca-70187b7fdd74	lxalgo_001:entry:1761338405183	Buy	8.31800000	24.00000000	2025-10-24 20:40:05.895+00	entry	0.00000000	2025-10-24 20:40:05.939814+00
19	shortseller_001	BTCUSDT	15e1c14a-5734-41a2-a8e5-0202dc48d189	shortseller_001:entry:1761338406382	Buy	110669.20000000	0.00400000	2025-10-24 20:40:06.781+00	entry	0.00000000	2025-10-24 20:40:06.781073+00
20	shortseller_001	BTCUSDT	8ff06a36-aec3-4057-9538-fec08e33f688	shortseller_001:all_bots_test:1761338460965	Sell	110692.10000000	0.00100000	2025-10-24 20:41:01.372+00	all_bots_test	0.00000000	2025-10-24 20:41:01.366512+00
21	lxalgo_001	CLANKERUSDT	f849b36f-2e30-4f1d-b5c7-19e6427f77f6	lxalgo_001:entry:1761339001304	Buy	70.98000000	2.81000000	2025-10-24 20:50:02.825+00	entry	0.00000000	2025-10-24 20:50:02.778748+00
22	lxalgo_001	APRUSDT	5074f699-c138-4823-bddd-d3b33a1587e1	lxalgo_001:entry:1761339005953	Buy	0.49550000	404.00000000	2025-10-24 20:50:07.012+00	entry	0.00000000	2025-10-24 20:50:06.960649+00
23	lxalgo_001	CLANKERUSDT	03f8bef2-824c-40a8-a3fa-239764f40ec6	lxalgo_001:entry:1761343501385	Buy	80.99000000	2.45000000	2025-10-24 22:05:01.919+00	entry	0.00000000	2025-10-24 22:05:02.065343+00
24	shortseller_001	BTCUSDT	8a108453-f1b6-4f5e-b61f-2e71d84a0b1b	shortseller_001:entry:1761343505722	Buy	110895.70000000	0.00100000	2025-10-24 22:05:06.003+00	entry	0.00000000	2025-10-24 22:05:06.147052+00
25	lxalgo_001	HUSDT	47267d80-15c9-49ab-b729-15b7fd1d740c	lxalgo_001:entry:1761343801378	Buy	0.33613000	590.00000000	2025-10-24 22:10:01.805+00	entry	0.00000000	2025-10-24 22:10:01.955189+00
26	unknown	APRUSDT	16e92ba8-890f-433f-952c-abace72c2364		Sell	0.45440000	404.00000000	2025-10-24 22:11:07.067+00		0.00000000	2025-10-24 22:11:07.263262+00
27	lxalgo_001	PIPPINUSDT	12ca2bf8-d6ff-4224-99e7-2b6c3adb15c1	lxalgo_001:entry:1761345001345	Buy	0.02344000	8554.00000000	2025-10-24 22:30:02.281+00	entry	0.00000000	2025-10-24 22:30:02.443453+00
28	lxalgo_001	AIAUSDT	cd1d9802-dc97-4c89-a888-e017451a2c42	lxalgo_001:entry:1761345004210	Buy	1.48670000	134.00000000	2025-10-24 22:30:04.637+00	entry	0.00000000	2025-10-24 22:30:04.784657+00
29	shortseller_001	BTCUSDT	82d5d1e5-6344-44c4-8efc-0e59b18c69f7	shortseller_001:all_bots_test:1761345010123	Sell	111016.80000000	0.00100000	2025-10-24 22:30:10.358+00	all_bots_test	0.00000000	2025-10-24 22:30:10.504982+00
30	shortseller_001	BTCUSDT	2210c313-8a03-4cb8-92e0-207693f98f61	shortseller_001:all_bots_test:1761345621105	Sell	111023.10000000	0.00100000	2025-10-24 22:40:21.352+00	all_bots_test	0.00000000	2025-10-24 22:40:21.491661+00
31	unknown	AIAUSDT	c7066587-48eb-479e-9543-73a9c6fe36a0		Buy	1.49900000	134.00000000	2025-10-24 23:00:00+00		0.00000000	2025-10-24 23:00:00.184112+00
32	unknown	HUSDT	11c10517-cc70-4ba1-8693-72fbe7b36d84		Buy	0.33248500	590.00000000	2025-10-24 23:00:00+00		0.00000000	2025-10-24 23:00:00.194917+00
33	unknown	CLANKERUSDT	fdc5b068-0dd8-434c-9897-10539e6b56d6		Sell	72.70000000	8.18000000	2025-10-24 23:19:04.719+00		0.00000000	2025-10-24 23:19:04.858806+00
34	unknown	BTCUSDT	dcc6e77b-a96a-43c8-98e0-5a7a3256c193		Sell	110964.70000000	0.00200000	2025-10-25 00:00:00+00		0.00000000	2025-10-25 00:00:00.157942+00
35	unknown	SPKUSDT	7a690d8a-6b7f-4a62-95c3-e0b63f449f26		Buy	0.04399000	9040.00000000	2025-10-25 00:00:00+00		0.00000000	2025-10-25 00:00:01.65119+00
36	unknown	EVAAUSDT	057fb8f5-1994-4259-a910-e4d8ea4e6393		Buy	9.65000000	24.00000000	2025-10-25 00:00:00+00		0.00000000	2025-10-25 00:00:02.068624+00
37	unknown	AIAUSDT	4bb1e9f7-444d-4022-b6d9-c23a8b34f534		Buy	1.47460000	134.00000000	2025-10-25 00:00:00+00		0.00000000	2025-10-25 00:00:02.287135+00
38	unknown	HUSDT	2225b4cb-347a-409c-b0fe-430324183443		Buy	0.37966600	590.00000000	2025-10-25 00:00:00+00		0.00000000	2025-10-25 00:00:02.316139+00
39	unknown	PIPPINUSDT	5aeb9da5-22ea-40af-a780-e713f3e10456		Buy	0.02511000	8554.00000000	2025-10-25 00:00:00+00		0.00000000	2025-10-25 00:00:02.317574+00
40	lxalgo_001	HUSDT	eae20204-be9d-42f1-8d07-1e23f1dfb2d2	lxalgo_001:entry:1761350404866	Buy	0.38529500	520.00000000	2025-10-25 00:00:05.312+00	entry	0.00000000	2025-10-25 00:00:05.438086+00
41	lxalgo_001	EVAAUSDT	eb9f84c5-ff1b-4194-880b-5990e5b673c9	lxalgo_001:entry:1761350406604	Buy	9.69700000	20.70000000	2025-10-25 00:00:07.052+00	entry	0.00000000	2025-10-25 00:00:07.177244+00
42	unknown	HUSDT	05f9bf08-64ca-402e-841a-980489b8217b		Sell	0.35009700	1110.00000000	2025-10-25 00:11:09.894+00		0.00000000	2025-10-25 00:11:10.053775+00
43	lxalgo_001	FUSDT	b00698e8-105c-45b0-b0bf-e0616a035f9b	lxalgo_001:entry:1761352201276	Buy	0.02628500	7597.00000000	2025-10-25 00:30:01.724+00	entry	0.00000000	2025-10-25 00:30:01.844603+00
44	lxalgo_001	CLANKERUSDT	63225ff6-9624-4dff-985a-414fcb368dda	lxalgo_001:entry:1761353102117	Buy	81.40000000	2.46000000	2025-10-25 00:45:03.073+00	entry	0.00000000	2025-10-25 00:45:03.193584+00
45	lxalgo_001	ZKCUSDT	781798d0-af16-4c01-abce-f8c449b4f223	lxalgo_001:entry:1761353701633	Buy	0.26890000	744.80000000	2025-10-25 00:55:02.65+00	entry	0.00000000	2025-10-25 00:55:02.771983+00
46	unknown	AIAUSDT	2824bdb2-4e7d-40ed-b5f4-b9533a77b0d0		Buy	1.42940000	134.00000000	2025-10-25 01:00:00+00		0.00000000	2025-10-25 01:00:00.181462+00
47	unknown	FUSDT	2fb91f32-a794-4118-aa84-f9fc3f10eb13		Buy	0.02888700	7597.00000000	2025-10-25 01:00:00+00		0.00000000	2025-10-25 01:00:00.185534+00
48	lxalgo_001	KGENUSDT	c64ec55d-e591-428d-b87a-bb982144d4c2	lxalgo_001:entry:1761354303380	Buy	0.36660000	544.00000000	2025-10-25 01:05:03.837+00	entry	0.00000000	2025-10-25 01:05:03.959411+00
49	lxalgo_001	BLUAIUSDT	321e5632-6cae-4075-94b3-701d4b03c765	lxalgo_001:entry:1761356101767	Buy	0.02794000	7170.00000000	2025-10-25 01:35:02.225+00	entry	0.00000000	2025-10-25 01:35:02.343994+00
50	unknown	CLANKERUSDT	5b70d234-af1d-4e3a-9d73-a323fd0baff6		Sell	81.02000000	2.46000000	2025-10-25 01:37:25.529+00		0.00000000	2025-10-25 01:37:25.657645+00
51	unknown	AIAUSDT	d97f7b17-fcd0-46f0-80c1-b9c556ab714d		Buy	1.39050000	134.00000000	2025-10-25 02:00:00+00		0.00000000	2025-10-25 02:00:00.087111+00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: trading; Owner: trading_user
--

COPY trading.orders (id, bot_id, symbol, order_id, client_order_id, order_type, side, quantity, price, status, created_at, updated_at) FROM stdin;
1	shortseller_001	BTCUSDT	8e1ccad6-4502-49c4-938b-06bc2dd828e8	shortseller_001:phase3_test:1761283037712	Market	Sell	0.00100000	109995.70000000	Filled	2025-10-24 05:17:18.195654+00	2025-10-24 05:17:18.195654+00
4	shortseller_001	BTCUSDT	7a3b5f9a-ac33-453b-968f-353013edecb8	shortseller_001:entry:1761283206549	Market	Buy	0.00200000	112203.10000000	Filled	2025-10-24 05:20:07.449096+00	2025-10-24 05:20:07.449096+00
2	unknown	BTCUSDT	bcbec7ca-33fa-4679-b60a-ce33f8b20a5d		Market	Buy	0.00200000	0.00000000	Deactivated	2025-10-24 05:17:18.197784+00	2025-10-24 05:20:07.450802+00
3	unknown	BTCUSDT	1a3a8195-6c3d-46bb-96e8-39a5ac7bb721		Market	Buy	0.00200000	0.00000000	Deactivated	2025-10-24 05:17:18.198873+00	2025-10-24 05:20:07.451828+00
7	shortseller_001	BTCUSDT	5110444b-d72b-496a-a49c-cecc9e364fc9	shortseller_001:phase3_test:1761283232355	Market	Sell	0.00100000	109895.70000000	Filled	2025-10-24 05:20:33.278061+00	2025-10-24 05:20:33.278061+00
10	shortseller_001	BTCUSDT	29699880-a2e8-4e4f-9f55-4e6e7ebcfb2c	shortseller_001:phase3_test:1761283351221	Market	Sell	0.00100000	109791.60000000	Filled	2025-10-24 05:22:32.120203+00	2025-10-24 05:22:32.120203+00
41	unknown	CLANKERUSDT	4cc533f1-1b56-4860-ad60-b461b6337da8		Market	Sell	2.92000000	0.00000000	Deactivated	2025-10-24 20:35:07.456888+00	2025-10-24 23:19:04.861687+00
77	lxalgo_001	CLANKERUSDT	03f8bef2-824c-40a8-a3fa-239764f40ec6	lxalgo_001:entry:1761343501385	Market	Buy	2.45000000	93.09000000	Filled	2025-10-24 22:05:02.075683+00	2025-10-24 22:05:02.075683+00
13	unknown	BTCUSDT	cc1f84a5-b9fb-404b-9048-7d7c918a64ee		Market	Buy	0.00200000	112140.10000000	Filled	2025-10-24 05:25:08.238512+00	2025-10-24 05:25:08.238512+00
8	unknown	BTCUSDT	8062df76-0a42-4108-88f3-ba762d76f2e6		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 05:20:33.279612+00	2025-10-24 05:25:08.239789+00
9	unknown	BTCUSDT	ca5dcdbe-9a48-4bbf-98cc-36aac8b8649b		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 05:20:33.280503+00	2025-10-24 05:25:08.240844+00
16	shortseller_001	BTCUSDT	86fd4fd1-7af0-487f-8a6a-abaf2fb3d671	shortseller_001:phase3_test:1761283583696	Market	Sell	0.00100000	109912.70000000	Filled	2025-10-24 05:26:24.09032+00	2025-10-24 05:26:24.09032+00
19	unknown	BTCUSDT	3fa47291-b8dd-4d58-a79b-102648c59b93		Market	Buy	0.00100000	112125.20000000	Filled	2025-10-24 05:27:03.238323+00	2025-10-24 05:27:03.238323+00
17	unknown	BTCUSDT	b28a33fe-e6dd-489d-8683-765a06f9b552		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 05:26:24.091792+00	2025-10-24 05:27:03.239399+00
18	unknown	BTCUSDT	effe2a2f-38ac-4615-ac03-b861e8fede18		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 05:26:24.093026+00	2025-10-24 05:27:03.240432+00
22	shortseller_001	BTCUSDT	15a5d347-99b4-4026-a492-af15030bd033	shortseller_001:phase3_test:1761285450084	Market	Sell	0.00100000	110100.20000000	Filled	2025-10-24 05:57:30.516037+00	2025-10-24 05:57:30.516037+00
25	unknown	BTCUSDT	1fd632ad-f42b-43a8-971d-74656f34e51b		Market	Buy	0.00100000	112332.50000000	Filled	2025-10-24 05:59:51.353604+00	2025-10-24 05:59:51.353604+00
23	unknown	BTCUSDT	7d63205c-2b88-4ad3-ba64-1a6db7475e25		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 05:57:30.517201+00	2025-10-24 05:59:51.354893+00
24	unknown	BTCUSDT	6e84ad96-263b-4c88-99d6-3f01077660b5		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 05:57:30.518063+00	2025-10-24 05:59:51.356028+00
28	shortseller_001	BTCUSDT	c4bb874f-1e76-41fd-8ea2-bbd3688e3784	shortseller_001:all_bots_test:1761337222890	Market	Sell	0.00100000	109594.30000000	Filled	2025-10-24 20:20:23.351086+00	2025-10-24 20:20:23.351086+00
31	lxalgo_001	SPKUSDT	5fbb8242-8539-423f-87fe-35182f26e18c	lxalgo_001:entry:1761337801402	Market	Buy	4650.00000000	0.04723000	Filled	2025-10-24 20:30:02.027448+00	2025-10-24 20:30:02.027448+00
35	shortseller_001	BTCUSDT	a9444782-d480-41cc-9fae-1e64b6959263	shortseller_001:all_bots_test:1761337870189	Market	Sell	0.00100000	109534.00000000	Filled	2025-10-24 20:31:10.590647+00	2025-10-24 20:31:10.590647+00
63	unknown	BTCUSDT	272c2342-dba4-4e62-a762-c979d74503aa		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 20:41:01.379025+00	2025-10-24 22:05:06.158668+00
32	unknown	SPKUSDT	ca0dba40-8b64-49bd-a74a-4caad25fcfd7		Market	Sell	4650.00000000	0.00000000	Untriggered	2025-10-24 20:30:03.361362+00	2025-10-24 20:40:04.472694+00
38	lxalgo_001	CLANKERUSDT	1971d984-81c9-46e0-bcd7-b637db4ef3d5	lxalgo_001:entry:1761338104012	Market	Buy	2.92000000	77.99000000	Filled	2025-10-24 20:35:05.108011+00	2025-10-24 20:35:05.108011+00
42	shortseller_001	BTCUSDT	0758b8e0-daa3-4712-8912-5d83ad8a18e8	shortseller_001:all_bots_test:1761338193283	Market	Sell	0.00100000	109593.70000000	Filled	2025-10-24 20:36:33.679108+00	2025-10-24 20:36:33.679108+00
33	unknown	SPKUSDT	a01dde35-85a3-4435-8ed4-712bd654646a		Market	Sell	4650.00000000	0.00000000	Untriggered	2025-10-24 20:30:03.36864+00	2025-10-24 20:40:04.474319+00
34	unknown	SPKUSDT	847e253f-ceb6-40b3-9f6c-abf9d5a82745		Market	Sell	4650.00000000	0.00000000	Untriggered	2025-10-24 20:30:03.369576+00	2025-10-24 20:40:04.475583+00
45	shortseller_001	BTCUSDT	7121f560-c8a4-477b-84e6-5156e3c1975d	shortseller_001:all_bots_test:1761338358429	Market	Sell	0.00100000	109511.10000000	Filled	2025-10-24 20:39:18.83204+00	2025-10-24 20:39:18.83204+00
57	unknown	EVAAUSDT	5cc31bdf-9525-44fb-b67a-9b0bd5d89af7		Market	Sell	24.00000000	0.00000000	Untriggered	2025-10-24 20:40:06.615762+00	2025-10-25 00:02:39.878096+00
48	lxalgo_001	SPKUSDT	a4e16f4a-b982-4d93-8c85-676c428138d7	lxalgo_001:entry:1761338402174	Market	Buy	4390.00000000	0.05021000	Filled	2025-10-24 20:40:03.299146+00	2025-10-24 20:40:03.299146+00
55	lxalgo_001	EVAAUSDT	45c3b9c9-192a-4e6a-99ca-70187b7fdd74	lxalgo_001:entry:1761338405183	Market	Buy	24.00000000	9.55300000	Filled	2025-10-24 20:40:05.950337+00	2025-10-24 20:40:05.950337+00
59	shortseller_001	BTCUSDT	15e1c14a-5734-41a2-a8e5-0202dc48d189	shortseller_001:entry:1761338406382	Market	Buy	0.00400000	111775.80000000	Filled	2025-10-24 20:40:06.79158+00	2025-10-24 20:40:06.79158+00
29	unknown	BTCUSDT	83b5f7ce-7009-4a16-a77d-d1a500a8443d		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 20:20:23.356248+00	2025-10-24 20:40:06.793067+00
30	unknown	BTCUSDT	8ad46c00-bd17-4eaa-b0e0-69753d11ff67		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 20:20:23.357967+00	2025-10-24 20:40:06.794019+00
62	shortseller_001	BTCUSDT	8ff06a36-aec3-4057-9538-fec08e33f688	shortseller_001:all_bots_test:1761338460965	Market	Sell	0.00100000	109585.60000000	Filled	2025-10-24 20:41:01.377174+00	2025-10-24 20:41:01.377174+00
65	lxalgo_001	CLANKERUSDT	f849b36f-2e30-4f1d-b5c7-19e6427f77f6	lxalgo_001:entry:1761339001304	Market	Buy	2.81000000	81.73000000	Filled	2025-10-24 20:50:02.789022+00	2025-10-24 20:50:02.789022+00
84	shortseller_001	BTCUSDT	8a108453-f1b6-4f5e-b61f-2e71d84a0b1b	shortseller_001:entry:1761343505722	Market	Buy	0.00100000	112004.70000000	Filled	2025-10-24 22:05:06.15744+00	2025-10-24 22:05:06.15744+00
72	lxalgo_001	APRUSDT	5074f699-c138-4823-bddd-d3b33a1587e1	lxalgo_001:entry:1761339005953	Market	Buy	404.00000000	0.56950000	Filled	2025-10-24 20:50:06.970593+00	2025-10-24 20:50:06.970593+00
64	unknown	BTCUSDT	1d723ef7-e916-4688-a645-567e82d9b86f		Market	Buy	0.00100000	0.00000000	Deactivated	2025-10-24 20:41:01.380057+00	2025-10-24 22:05:06.15965+00
40	unknown	CLANKERUSDT	fdc5b068-0dd8-434c-9897-10539e6b56d6		Market	Sell	2.92000000	0.00000000	Filled	2025-10-24 20:35:07.4558+00	2025-10-24 23:19:04.859931+00
88	lxalgo_001	HUSDT	47267d80-15c9-49ab-b729-15b7fd1d740c	lxalgo_001:entry:1761343801378	Market	Buy	590.00000000	0.38634100	Filled	2025-10-24 22:10:01.96502+00	2025-10-24 22:10:01.96502+00
74	unknown	APRUSDT	16e92ba8-890f-433f-952c-abace72c2364		Market	Sell	404.00000000	0.00000000	Filled	2025-10-24 20:50:07.783465+00	2025-10-24 22:11:07.264318+00
73	unknown	APRUSDT	c10dba82-e447-44df-97ca-1d8d67bc721d		Market	Sell	404.00000000	0.00000000	Deactivated	2025-10-24 20:50:07.775055+00	2025-10-24 22:11:07.2653+00
75	unknown	APRUSDT	ae0ba25b-0d5e-4a69-8cfa-d7947f5a4026		Market	Sell	404.00000000	0.00000000	Deactivated	2025-10-24 20:50:07.784738+00	2025-10-24 22:11:07.266427+00
56	unknown	EVAAUSDT	e94aa309-a51c-450b-a35c-85a847d2aeb4		Market	Sell	24.00000000	0.00000000	Untriggered	2025-10-24 20:40:06.607427+00	2025-10-25 00:00:07.758551+00
39	unknown	CLANKERUSDT	ee17aa57-4e01-4bad-9aad-9f9edbdc523a		Market	Sell	2.92000000	0.00000000	Deactivated	2025-10-24 20:35:07.445761+00	2025-10-24 23:19:04.860925+00
89	unknown	HUSDT	3cb6f78d-f18c-4564-8dba-7a4b94e17152		Market	Sell	590.00000000	0.00000000	Deactivated	2025-10-24 22:10:02.580619+00	2025-10-25 00:11:10.055828+00
58	unknown	EVAAUSDT	8f85e162-8fa0-4483-bd00-7c3d0981647c		Market	Sell	24.00000000	0.00000000	Untriggered	2025-10-24 20:40:06.616922+00	2025-10-25 00:00:07.769602+00
96	lxalgo_001	PIPPINUSDT	12ca2bf8-d6ff-4224-99e7-2b6c3adb15c1	lxalgo_001:entry:1761345001345	Market	Buy	8554.00000000	0.02693000	Filled	2025-10-24 22:30:02.453386+00	2025-10-24 22:30:02.453386+00
97	unknown	PIPPINUSDT	ca5f9c32-f5a8-4578-917d-309d0acaadf1		Market	Sell	8554.00000000	0.00000000	Untriggered	2025-10-24 22:30:03.512473+00	2025-10-24 22:30:03.512473+00
99	unknown	PIPPINUSDT	fae2cfe4-df7b-404c-ad4b-93bfc5daaf10		Market	Sell	8554.00000000	0.00000000	Untriggered	2025-10-24 22:30:03.522931+00	2025-10-24 22:30:03.522931+00
100	lxalgo_001	AIAUSDT	cd1d9802-dc97-4c89-a888-e017451a2c42	lxalgo_001:entry:1761345004210	Market	Buy	134.00000000	1.71080000	Filled	2025-10-24 22:30:04.794431+00	2025-10-24 22:30:04.794431+00
101	unknown	AIAUSDT	6074b5ae-cf64-4120-bcc5-630cefe33c82		Market	Sell	134.00000000	0.00000000	Untriggered	2025-10-24 22:30:05.369002+00	2025-10-24 22:30:05.369002+00
102	unknown	AIAUSDT	5c242728-dffc-46fc-a9d3-1ceeb4b66487		Market	Sell	134.00000000	0.00000000	Untriggered	2025-10-24 22:30:05.378232+00	2025-10-24 22:30:05.378232+00
103	unknown	AIAUSDT	b88735b9-3d40-4402-8147-dd58d7c2223a		Market	Sell	134.00000000	0.00000000	Untriggered	2025-10-24 22:30:05.379409+00	2025-10-24 22:30:05.379409+00
104	shortseller_001	BTCUSDT	82d5d1e5-6344-44c4-8efc-0e59b18c69f7	shortseller_001:all_bots_test:1761345010123	Market	Sell	0.00100000	109906.70000000	Filled	2025-10-24 22:30:10.515486+00	2025-10-24 22:30:10.515486+00
107	shortseller_001	BTCUSDT	2210c313-8a03-4cb8-92e0-207693f98f61	shortseller_001:all_bots_test:1761345621105	Market	Sell	0.00100000	109912.90000000	Filled	2025-10-24 22:40:21.501659+00	2025-10-24 22:40:21.501659+00
105	unknown	BTCUSDT	f8301682-d0b9-4db0-ade5-d085bc94408a		Market	Buy	0.00100000	0.00000000	Untriggered	2025-10-24 22:30:10.516718+00	2025-10-24 22:40:21.502943+00
106	unknown	BTCUSDT	015eff0c-1dd9-44a8-a7e2-7c97d3bab5a7		Market	Buy	0.00100000	0.00000000	Untriggered	2025-10-24 22:30:10.51761+00	2025-10-24 22:40:21.504073+00
142	unknown	CLANKERUSDT	5b70d234-af1d-4e3a-9d73-a323fd0baff6		Market	Sell	2.46000000	0.00000000	Filled	2025-10-25 00:45:04.275811+00	2025-10-25 01:37:25.659359+00
98	unknown	PIPPINUSDT	e4e66615-4700-4400-b0e3-0030277944b4		Market	Sell	8554.00000000	0.00000000	Untriggered	2025-10-24 22:30:03.521838+00	2025-10-24 23:56:09.378793+00
117	lxalgo_001	HUSDT	eae20204-be9d-42f1-8d07-1e23f1dfb2d2	lxalgo_001:entry:1761350404866	Market	Buy	520.00000000	0.44167800	Filled	2025-10-25 00:00:05.448074+00	2025-10-25 00:00:05.448074+00
141	unknown	CLANKERUSDT	66a20903-7f8f-4b15-b0f7-e2554951b21b		Market	Sell	2.46000000	0.00000000	Deactivated	2025-10-25 00:45:04.274651+00	2025-10-25 01:37:25.660402+00
143	unknown	CLANKERUSDT	815287c5-9f99-4864-ad84-df0321c450b2		Market	Sell	2.46000000	0.00000000	Deactivated	2025-10-25 00:45:04.276836+00	2025-10-25 01:37:25.661373+00
124	lxalgo_001	EVAAUSDT	eb9f84c5-ff1b-4194-880b-5990e5b673c9	lxalgo_001:entry:1761350406604	Market	Buy	20.70000000	11.12000000	Filled	2025-10-25 00:00:07.178858+00	2025-10-25 00:00:07.178858+00
90	unknown	HUSDT	05f9bf08-64ca-402e-841a-980489b8217b		Market	Sell	590.00000000	0.00000000	Filled	2025-10-24 22:10:02.587434+00	2025-10-25 00:11:10.055025+00
91	unknown	HUSDT	693c09ad-1a66-4905-8780-91d31d9cf3de		Market	Sell	590.00000000	0.00000000	Deactivated	2025-10-24 22:10:02.588988+00	2025-10-25 00:11:10.056787+00
136	lxalgo_001	FUSDT	b00698e8-105c-45b0-b0bf-e0616a035f9b	lxalgo_001:entry:1761352201276	Market	Buy	7597.00000000	0.03147700	Filled	2025-10-25 00:30:01.8545+00	2025-10-25 00:30:01.8545+00
137	unknown	FUSDT	d2c78c88-12a7-4637-a06b-81a74f77f627		Market	Sell	7597.00000000	0.00000000	Untriggered	2025-10-25 00:30:02.41213+00	2025-10-25 00:30:02.41213+00
139	unknown	FUSDT	3201a6b6-1797-4ec4-913b-86562de24998		Market	Sell	7597.00000000	0.00000000	Untriggered	2025-10-25 00:30:02.422945+00	2025-10-25 00:30:02.422945+00
140	lxalgo_001	CLANKERUSDT	63225ff6-9624-4dff-985a-414fcb368dda	lxalgo_001:entry:1761353102117	Market	Buy	2.46000000	93.29000000	Filled	2025-10-25 00:45:03.203652+00	2025-10-25 00:45:03.203652+00
144	lxalgo_001	ZKCUSDT	781798d0-af16-4c01-abce-f8c449b4f223	lxalgo_001:entry:1761353701633	Market	Buy	744.80000000	0.30910000	Filled	2025-10-25 00:55:02.781962+00	2025-10-25 00:55:02.781962+00
145	unknown	ZKCUSDT	690d9f60-f62a-4462-a58f-dbc63262d898		Market	Sell	744.80000000	0.00000000	Untriggered	2025-10-25 00:55:03.344195+00	2025-10-25 00:55:03.344195+00
146	unknown	ZKCUSDT	f4fb90b8-88ca-47f7-b3e1-2d4c2139e0f5		Market	Sell	744.80000000	0.00000000	Untriggered	2025-10-25 00:55:03.354103+00	2025-10-25 00:55:03.354103+00
147	unknown	ZKCUSDT	b66f3c65-55ce-452f-ba30-ec74ef33d117		Market	Sell	744.80000000	0.00000000	Untriggered	2025-10-25 00:55:03.355321+00	2025-10-25 00:55:03.355321+00
138	unknown	FUSDT	cb519a59-d102-4737-883c-d38d4fdae2c7		Market	Sell	7597.00000000	0.00000000	Untriggered	2025-10-25 00:30:02.421779+00	2025-10-25 00:55:33.703458+00
149	lxalgo_001	KGENUSDT	c64ec55d-e591-428d-b87a-bb982144d4c2	lxalgo_001:entry:1761354303380	Market	Buy	544.00000000	0.42150000	Filled	2025-10-25 01:05:03.969364+00	2025-10-25 01:05:03.969364+00
150	unknown	KGENUSDT	f45b52e0-eaec-4e9d-9193-dd998da3b2c0		Market	Sell	544.00000000	0.00000000	Untriggered	2025-10-25 01:05:04.53495+00	2025-10-25 01:05:04.53495+00
151	unknown	KGENUSDT	b0fa6ac1-68cc-42b7-bb87-fd32873773f5		Market	Sell	544.00000000	0.00000000	Untriggered	2025-10-25 01:05:04.541671+00	2025-10-25 01:05:04.541671+00
152	unknown	KGENUSDT	3ac7d26c-d76a-4df7-879d-25aca4c1c7e3		Market	Sell	544.00000000	0.00000000	Untriggered	2025-10-25 01:05:04.542806+00	2025-10-25 01:05:04.542806+00
154	lxalgo_001	BLUAIUSDT	321e5632-6cae-4075-94b3-701d4b03c765	lxalgo_001:entry:1761356101767	Market	Buy	7170.00000000	0.03199000	Filled	2025-10-25 01:35:02.354311+00	2025-10-25 01:35:02.354311+00
155	unknown	BLUAIUSDT	e02dea04-fd79-4ca8-9fa1-70bf82a3d54d		Market	Sell	7170.00000000	0.00000000	Untriggered	2025-10-25 01:35:03.417794+00	2025-10-25 01:35:03.417794+00
156	unknown	BLUAIUSDT	a7a679a8-19de-4c9b-b7ea-f0e715f763b2		Market	Sell	7170.00000000	0.00000000	Untriggered	2025-10-25 01:35:03.41909+00	2025-10-25 01:35:03.41909+00
157	unknown	BLUAIUSDT	8d9e8ddb-ab59-4505-a963-e0dfd60258be		Market	Sell	7170.00000000	0.00000000	Untriggered	2025-10-25 01:35:03.42007+00	2025-10-25 01:35:03.42007+00
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: trading; Owner: trading_user
--

COPY trading.positions (id, bot_id, symbol, size, side, avg_entry_price, updated_at) FROM stdin;
199	shortseller_001	ZKCUSDT	744.80000000	Buy	\N	2025-10-25 00:55:03.356676+00
200	lxalgo_001	ZKCUSDT	744.80000000	Buy	\N	2025-10-25 00:55:03.356676+00
201	momentum_001	ZKCUSDT	744.80000000	Buy	\N	2025-10-25 00:55:03.356676+00
1	shortseller_001	BTCUSDT	0.00200000	Sell	\N	2025-10-25 00:00:01.223237+00
2	lxalgo_001	BTCUSDT	0.00200000	Sell	\N	2025-10-25 00:00:01.223237+00
3	momentum_001	BTCUSDT	0.00200000	Sell	\N	2025-10-25 00:00:01.223237+00
31	shortseller_001	SPKUSDT	9040.00000000	Buy	\N	2025-10-25 00:00:03.465412+00
32	lxalgo_001	SPKUSDT	9040.00000000	Buy	\N	2025-10-25 00:00:03.465412+00
33	momentum_001	SPKUSDT	9040.00000000	Buy	\N	2025-10-25 00:00:03.465412+00
115	shortseller_001	AIAUSDT	134.00000000	Buy	\N	2025-10-25 01:00:00.303409+00
116	lxalgo_001	AIAUSDT	134.00000000	Buy	\N	2025-10-25 01:00:00.303409+00
117	momentum_001	AIAUSDT	134.00000000	Buy	\N	2025-10-25 01:00:00.303409+00
109	shortseller_001	PIPPINUSDT	8554.00000000	Buy	\N	2025-10-25 00:00:03.920623+00
110	lxalgo_001	PIPPINUSDT	8554.00000000	Buy	\N	2025-10-25 00:00:03.920623+00
111	momentum_001	PIPPINUSDT	8554.00000000	Buy	\N	2025-10-25 00:00:03.920623+00
187	shortseller_001	FUSDT	7597.00000000	Buy	\N	2025-10-25 01:00:00.332974+00
188	lxalgo_001	FUSDT	7597.00000000	Buy	\N	2025-10-25 01:00:00.332974+00
189	momentum_001	FUSDT	7597.00000000	Buy	\N	2025-10-25 01:00:00.332974+00
76	shortseller_001	APRUSDT	0.00000000		\N	2025-10-24 22:11:07.271597+00
77	lxalgo_001	APRUSDT	0.00000000		\N	2025-10-24 22:11:07.271597+00
78	momentum_001	APRUSDT	0.00000000		\N	2025-10-24 22:11:07.271597+00
214	shortseller_001	KGENUSDT	544.00000000	Buy	\N	2025-10-25 01:05:04.544034+00
215	lxalgo_001	KGENUSDT	544.00000000	Buy	\N	2025-10-25 01:05:04.544034+00
216	momentum_001	KGENUSDT	544.00000000	Buy	\N	2025-10-25 01:05:04.544034+00
223	shortseller_001	BLUAIUSDT	7170.00000000	Buy	\N	2025-10-25 01:35:03.421295+00
224	lxalgo_001	BLUAIUSDT	7170.00000000	Buy	\N	2025-10-25 01:35:03.421295+00
225	momentum_001	BLUAIUSDT	7170.00000000	Buy	\N	2025-10-25 01:35:03.421295+00
40	shortseller_001	CLANKERUSDT	0.00000000		\N	2025-10-25 01:37:25.665215+00
41	lxalgo_001	CLANKERUSDT	0.00000000		\N	2025-10-25 01:37:25.665215+00
42	momentum_001	CLANKERUSDT	0.00000000		\N	2025-10-25 01:37:25.665215+00
58	shortseller_001	EVAAUSDT	44.70000000	Buy	\N	2025-10-25 00:02:39.913824+00
59	lxalgo_001	EVAAUSDT	44.70000000	Buy	\N	2025-10-25 00:02:39.913824+00
60	momentum_001	EVAAUSDT	44.70000000	Buy	\N	2025-10-25 00:02:39.913824+00
97	shortseller_001	HUSDT	0.00000000		\N	2025-10-25 00:11:10.060239+00
98	lxalgo_001	HUSDT	0.00000000		\N	2025-10-25 00:11:10.060239+00
99	momentum_001	HUSDT	0.00000000		\N	2025-10-25 00:11:10.060239+00
\.


--
-- Name: fills_id_seq; Type: SEQUENCE SET; Schema: trading; Owner: trading_user
--

SELECT pg_catalog.setval('trading.fills_id_seq', 52, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: trading; Owner: trading_user
--

SELECT pg_catalog.setval('trading.orders_id_seq', 161, true);


--
-- Name: positions_id_seq; Type: SEQUENCE SET; Schema: trading; Owner: trading_user
--

SELECT pg_catalog.setval('trading.positions_id_seq', 234, true);


--
-- Name: bots bots_pkey; Type: CONSTRAINT; Schema: trading; Owner: trading_user
--

ALTER TABLE ONLY trading.bots
    ADD CONSTRAINT bots_pkey PRIMARY KEY (bot_id);


--
-- Name: fills fills_pkey; Type: CONSTRAINT; Schema: trading; Owner: trading_user
--

ALTER TABLE ONLY trading.fills
    ADD CONSTRAINT fills_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_id_key; Type: CONSTRAINT; Schema: trading; Owner: trading_user
--

ALTER TABLE ONLY trading.orders
    ADD CONSTRAINT orders_order_id_key UNIQUE (order_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: trading; Owner: trading_user
--

ALTER TABLE ONLY trading.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: trading; Owner: trading_user
--

ALTER TABLE ONLY trading.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: positions unique_bot_symbol; Type: CONSTRAINT; Schema: trading; Owner: trading_user
--

ALTER TABLE ONLY trading.positions
    ADD CONSTRAINT unique_bot_symbol UNIQUE (bot_id, symbol);


--
-- Name: idx_bots_status; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_bots_status ON trading.bots USING btree (status);


--
-- Name: idx_bots_type; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_bots_type ON trading.bots USING btree (bot_type);


--
-- Name: idx_fills_bot_symbol; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_fills_bot_symbol ON trading.fills USING btree (bot_id, symbol, exec_time DESC);


--
-- Name: idx_fills_client_id; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_fills_client_id ON trading.fills USING btree (client_order_id);


--
-- Name: idx_fills_close_reason; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_fills_close_reason ON trading.fills USING btree (close_reason);


--
-- Name: idx_fills_exec_time; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_fills_exec_time ON trading.fills USING btree (exec_time DESC);


--
-- Name: idx_fills_order_id; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_fills_order_id ON trading.fills USING btree (order_id);


--
-- Name: idx_orders_bot_id; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_orders_bot_id ON trading.orders USING btree (bot_id);


--
-- Name: idx_orders_client_id; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_orders_client_id ON trading.orders USING btree (client_order_id);


--
-- Name: idx_orders_status; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_orders_status ON trading.orders USING btree (status);


--
-- Name: idx_positions_bot_id; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_positions_bot_id ON trading.positions USING btree (bot_id);


--
-- Name: idx_positions_symbol; Type: INDEX; Schema: trading; Owner: trading_user
--

CREATE INDEX idx_positions_symbol ON trading.positions USING btree (symbol);


--
-- PostgreSQL database dump complete
--

\unrestrict vR3hVGwVM2xe9dZOiRd2pzhdvCKddNhZWsvSArJINBXBfWQbs0fFgoaiG5sUFB1

